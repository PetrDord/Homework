<?php

use Cal\math;

require __DIR__ . "/vendor/autoload.php";

$a= new math\Calculator;
$a->setX(5);
$a->setY(10);
$a->Plus();
/*$a->Minus();*/
/*$a->Krat();*/
/*$a->Deleno();*/